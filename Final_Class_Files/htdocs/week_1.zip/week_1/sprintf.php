<?php
// sprintf
// output is always a string
$cost = sprintf("*%01.2f", 3.2); //
echo $cost;
?>