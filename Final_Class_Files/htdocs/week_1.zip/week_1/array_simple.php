<?php
// array of names, print out (echo) Kool
$a = array("kool", "and", "the", "gang");
echo $a[0]; //kool
?>