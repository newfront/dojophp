<?php
// complex arrays
// key value pairs
$string = "hello\n\ncool";
//$string2 = 'hello\ncool';
$a = array("scott"=>"teacher","class"=>"php");
echo $a["class"]; //teacher
/*
echo '<br>';
echo $string;
echo '<br>';
echo $string2;
*/
?>
<html>
<head>
	<title>w3c can suck it</title>
</head>
<body>
	<p><pre><?=$string?></pre></p>
</body>
</html>