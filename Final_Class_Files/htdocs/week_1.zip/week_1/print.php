<?php
// print command
print("hello world");
?>