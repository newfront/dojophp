<?php
// print_f is a formatted print
/*
%b = integer passed as binary number
%c = integer passed as ASCII equivalent
%d = integer passed as Decimal Number
%f = floating-point number
%o = integer presented as octal number
%s = String
*/
$int = 100;
printf("%d bottles of beer on %s", $int, "the wall");

?>