<?php
$int = 'picinic';
$int2 = 'ants';
$int3 = 'beers';

echo $int .' jumps '.$int2.' over the '.$int3;
?>