<?php
// How to use the echo command
$string = 'Hello World';
echo $string;
?>