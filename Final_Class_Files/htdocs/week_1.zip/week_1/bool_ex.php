<?php
/*
This is a Boolean Example
*/

$bool = 1;

if($bool == true){
	echo 'this is true';
} else {
	echo 'this is false';
}

?>