<?php
// explode by pin (via aaron)
$string_to_explode = "Scott Jumping Snowboard Hello";
$str_arr = explode(' ',$string_to_explode);
echo $str_arr[3];
//
?>