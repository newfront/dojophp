<?php
/*
Same as strpos, but just the first occurence of a value
*/
$str = "basic_email@email.com";
echo strrpos($str,'@');
?>