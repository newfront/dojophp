<?php
/* 
functions
*/
function getClassSize($size){
	return 'This class size is '.$size;
}

$size = getClassSize(8);
echo $size;
?>