<?php
/*
function with multiple parameters
*/
function getBirthday($name,$date){
	return 'Your name is '.$name.' and your birthday is '.$date;
}
echo getBirthday('Aaron','May 14th, 1987');
?>