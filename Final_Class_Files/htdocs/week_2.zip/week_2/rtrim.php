<?php
/*
PHP rtrim FUNCTION
rtrim allows PHP to take a string and close the white space on the right side
of the string value
*/
$str = "Hello dear      ";
echo rtrim($str);
?>