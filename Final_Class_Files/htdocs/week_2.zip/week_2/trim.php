<?php
/*
PHP TRIM FUNCTION
trim allows PHP to take a string and close the white space within it and on
the sides of it as well
*/
$str = "    the boat is outside      the house";
echo trim($str);
?>