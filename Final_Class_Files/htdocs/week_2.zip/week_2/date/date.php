<?php
/*
Working with PHP Dates
http://php.net/manual/en/function.date.php
*/
$date = date('l jS \of F Y h:i:s A');
echo $date;
?>