<?php
$date = date('Y');
echo $date;
?>