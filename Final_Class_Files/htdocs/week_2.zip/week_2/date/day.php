<?php
$date = date('d');
//$date = date('D'); // Mon - Sun
//$date = date('j'); // 1 - 31
//$date = date('l'); // day name of the week
echo $date;
?>