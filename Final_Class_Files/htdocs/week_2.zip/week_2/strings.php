<?php
/*
Strings are useful to store everything from actual text to sleeper functions
*/
$str = "I wish the day would last just a little longer";
echo $str;
?>