<?php
/*
How long is a String? How many characters make up the whole word or words?
*/
$str = "This is a line of text with a certain number of characters";
echo strlen($str);
?>