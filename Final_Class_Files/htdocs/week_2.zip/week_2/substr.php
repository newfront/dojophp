<?php
/*
Substring Method
How do I find the first 30 characters of a string?
*/
$str = "Today I hope down the lane";
echo substr($str,0,10);
?>