<?php
/*
String to Lower Case
*/
$str = "HELLO";
echo strtolower($str);
?>