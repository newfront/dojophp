<html>
<head>
	<title>Php is cool</title>
</head>
<body>
	<!--<?php 
	//if(true) :?>
<p><?#= 'cool'?></p>
<?#php endif;?>
</body>
</html>