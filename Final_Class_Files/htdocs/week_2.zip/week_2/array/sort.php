<?php
/*
array sort
//usort

*/
$p = array("a","b","d","c","g");
print_r($p);
sort($p);
print_r($p);
?>