<?php
/*
Add single slash to all quotes
*/
//$str_single = 'hello\nhello';
//$str_single_2 = "hello\nhello";

$str = "how is thing\"'s you do?";
echo addslashes($str);
?>