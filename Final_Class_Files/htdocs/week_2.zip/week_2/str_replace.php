<?php
/*
You want to replace a certain piece of a string value with another
*/
$str = "the dog jumps over my back while I am sleeping";
$rep = "face";
//echo str_replace('jumps',$rep,$str);
echo str_replace('jumps','scott',$str);
?>