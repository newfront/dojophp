<?php
/*
MATH
http://php.net/manual/en/book.math.php
*/
//ceil
//floor
//abs
//max
//min
//rand
//round
//pi
$arr = array(30,40,50,20,200,100);
echo max($arr);
/*
$m = round(20.75,0);
$m = round(200.375,2); //precision
*/
//echo round(200.375,2);
//echo pi
?>