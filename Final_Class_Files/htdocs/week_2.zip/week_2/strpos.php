<?php
/*
String Position
where is that amperstand in this sentance
*/
$str = "Howdy @ you are looking good";
echo strpos($str,'@');
?>