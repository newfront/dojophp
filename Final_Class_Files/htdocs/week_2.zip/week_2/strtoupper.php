<?php
/*
String to Upper Case
*/
$str = "hello world";
//echo strtoupper($str);
echo ucwords($str);
?>