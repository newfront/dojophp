<?php
/*
Same as strpos, but just the last occurence of a value
*/
$str = "basic_email@email@@@@.@.com";
echo strripos($str,'@');
?>