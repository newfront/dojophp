<?php
/*
PHP ltrim rtrim FUNCTION
ltrim allows PHP to take a string and close the white space on the left side
of the string value
*/
$str = "      Hello dear                    ";
echo ltrim(rtrim($str));
?>