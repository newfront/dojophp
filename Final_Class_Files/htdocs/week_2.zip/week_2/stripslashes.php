<?php
/*
Remove single slash to all quotes
*/
$str = "how is thing\'s you do?";
echo stripslashes($str);
?>