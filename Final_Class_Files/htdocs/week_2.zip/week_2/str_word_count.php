<?php
/*
Check for the total words in a string
*/
$str = "One Two Three and Maybe Four";
echo str_word_count($str);
?>