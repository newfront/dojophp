<?php
$bool = false;

if(is_bool($bool)){
	echo 'is boolean';
}

?>