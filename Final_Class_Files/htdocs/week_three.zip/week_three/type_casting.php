<?php
$number = 2.45676;
$integer = "Scott";

if(is_integer((integer) $integer)){
	echo 'is an integer';
} else {
	echo 'is not an integer';
}

/*if(is_string((string) $number)){
	echo 'is string';
} else {
	echo 'is not string';
}*/

/*echo (integer) $integer;*/

?>