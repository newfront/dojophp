<?php
//just included all our methods for our Blog Homepage
$basic = "Test that this is publicly available";

?>