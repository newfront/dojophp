<?php
// get recent blog entries
require_once 'classes/clsBlog.php';
?>