<?php
//another example of a controller file brought in to help us on our way
$more = "you said it";
?>