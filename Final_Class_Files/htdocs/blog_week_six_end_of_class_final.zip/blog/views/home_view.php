<div id="mainwrap">
	<div class="main_view_left">
	</div>
	<div class="main_view_right">
	</div>
	<div class="clearfix"></div>
	<div class="bottom_view">
	</div>
</div>