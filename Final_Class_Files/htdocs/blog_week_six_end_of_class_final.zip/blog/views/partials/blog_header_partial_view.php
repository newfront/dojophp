<div id="blog_head">
	<!-- Navigational Jump Menu -->
	<div class="dojo_logo"></div>
	<ul class="simple_nav">
		<?= $simple_navigation?>
	</ul>
</div>