<div id="mainwrap">
	<div class="main_view_left">
		Blog POST
	</div>
	<div class="main_view_right">
		Blog Modules
	</div>
	<div class="clearfix"></div>
	<div class="bottom_view">
		Common Links / Upcoming / Etc
	</div>
</div>