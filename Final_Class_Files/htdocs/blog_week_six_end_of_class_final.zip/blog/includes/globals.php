<?php
// get our Global Variables and Bring them into the page to Play with!
$globals = new Globals();
?>