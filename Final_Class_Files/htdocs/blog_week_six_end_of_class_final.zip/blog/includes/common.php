<?php
require_once('classes/clsGlobals.php');
require_once('classes/clsDatabase.php');
require_once('classes/clsLayout.php');
$globs = Globals::getPageInfo();
?>